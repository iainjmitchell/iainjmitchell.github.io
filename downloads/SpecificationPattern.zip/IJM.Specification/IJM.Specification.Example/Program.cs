﻿using System;
using System.Collections.Generic;
using IJM.Specification.Example.Specifications;
using IJM.Specification.Example.ValueObjects;

namespace IJM.Specification.Example
{
    class Program
    {
        static void Main(string[] args)
        {
            var accounts = new List<BankAccount>();
            accounts.Add(new BankAccount(1, "", 1, 0));
            accounts.Add(new BankAccount(2, "a name", 10, 0));
            accounts.Add(new BankAccount(3, "another name", 0, -10));
            accounts.Add(new BankAccount(4, "yet another", 0, 0));

            ISpecification<BankAccount> validAccountSpec = new ValidAccountSpecification();
            ISpecification<BankAccount> accountHasFunds = new AccountHasFundsSpecification();

            ISpecification<BankAccount> validAndHasFunds = 
                new ValidAccountSpecification().And(new AccountHasFundsSpecification());

            ISpecification<BankAccount> canWithdraw =
                new AccountHasFundsSpecification().Or(new WithinOverdraftSpecification());

            ISpecification<BankAccount> safeAccount =
                new ValidAccountSpecification().And(new AccountHasFundsSpecification().Or(new WithinOverdraftSpecification()));

            foreach(var account in accounts)
            {
                Console.WriteLine(String.Format("Account {0}", account.Id));
                //is valid account?
                if (!validAccountSpec.IsSatisfiedBy(account))
                {
                    Console.WriteLine("...is NOT valid");
                }
                else
                {
                    Console.WriteLine("...is valid");
                }

                //does account have funds?
                if (!accountHasFunds.IsSatisfiedBy(account))
                {
                    Console.WriteLine("...does NOT have funds");
                }
                else
                {
                    Console.WriteLine("...does have funds");
                }

                //valid and has funds?
                if (!validAndHasFunds.IsSatisfiedBy(account))
                {
                    Console.WriteLine("...is either NOT valid or does NOT have funds");
                }
                else
                {
                    Console.WriteLine("...is valid AND does have funds");
                }

                //can withdraw?
                if (!canWithdraw.IsSatisfiedBy(account))
                {
                    Console.WriteLine("...you cannot withdraw");
                }
                else
                {
                    Console.WriteLine("...you can withdraw");                    
                }

                //safe account?
                if (!safeAccount.IsSatisfiedBy(account))
                {
                    Console.WriteLine("...is NOT a safe account");
                }
                else
                {
                    Console.WriteLine("...is a safe account");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
